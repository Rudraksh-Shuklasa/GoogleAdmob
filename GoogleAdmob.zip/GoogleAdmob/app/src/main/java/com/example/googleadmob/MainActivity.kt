package com.example.googleadmob

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds

class MainActivity : AppCompatActivity() {

    var TAG="Banner Ad Example"

    lateinit var mAdView : AdView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        MobileAds.initialize(this) {}

        mAdView =findViewById(R.id.adView)
        val adLoad=AdRequest.Builder().build()
        mAdView.loadAd(adLoad)

        mAdView.adListener=object  : AdListener(){
            override fun onAdClicked() {
                super.onAdClicked()
                Log.d(TAG,"onAdClicked")
            }

            override fun onAdClosed() {
                super.onAdClosed()
                Log.d(TAG,"onAdClosed")
            }

            override fun onAdFailedToLoad(p0: Int) {
                super.onAdFailedToLoad(p0)
                Log.d(TAG,"onAdFailedToLoad")
            }

            override fun onAdLoaded() {
                super.onAdLoaded()
                Log.d(TAG,"onAdLoaded")
            }

            override fun onAdImpression() {
                super.onAdImpression()
                Log.d(TAG,"onAdImpression")
            }

            override fun onAdLeftApplication() {
                super.onAdLeftApplication()
                Log.d(TAG,"onAdLeftApplication")
            }

            override fun onAdOpened() {
                super.onAdOpened()
                Log.d(TAG,"onAdOpened")
            }
        }

    }
}
